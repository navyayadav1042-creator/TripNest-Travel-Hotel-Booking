<?php
if (session_status() === PHP_SESSION_NONE) session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= isset($pageTitle) ? htmlspecialchars($pageTitle) : 'TripNest' ?></title>
  <link rel="stylesheet" href="assets/css/style.css">
  <script defer src="assets/js/main.js"></script>
</head>
<body>
<header class="site-header">
  <a class="brand" href="index.php"><span class="brand-mark">✦</span> TripNest</a>
  <button class="menu-toggle" aria-label="Toggle navigation">☰</button>
  <nav class="nav-links">
    <a href="index.php">Home</a>
    <a href="hotels.php">Hotels</a>
    <?php if (!empty($_SESSION['user_id'])): ?>
      <a href="my-bookings.php">My Bookings</a>
      <?php if (($_SESSION['role'] ?? '') === 'admin'): ?><a href="admin/index.php">Admin</a><?php endif; ?>
      <a class="nav-cta" href="logout.php">Logout</a>
    <?php else: ?>
      <a href="login.php">Login</a>
      <a class="nav-cta" href="register.php">Sign up</a>
    <?php endif; ?>
  </nav>
</header>
<main>
