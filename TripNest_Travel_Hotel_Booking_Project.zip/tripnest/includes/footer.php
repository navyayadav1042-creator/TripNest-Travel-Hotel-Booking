</main>
<footer class="footer">
  <div><a class="brand footer-brand" href="index.php">✦ TripNest</a><p>Find your place. Make your journey memorable.</p></div>
  <p>© <?= date('Y') ?> TripNest. Academic project demo.</p>
</footer>
</body>
</html>
