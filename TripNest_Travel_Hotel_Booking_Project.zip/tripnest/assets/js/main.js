document.addEventListener('DOMContentLoaded', () => {
  const toggle = document.querySelector('.menu-toggle');
  const nav = document.querySelector('.nav-links');
  if (toggle && nav) toggle.addEventListener('click', () => nav.classList.toggle('open'));

  const today = new Date();
  const localDate = d => {
    const x = new Date(d.getTime() - d.getTimezoneOffset() * 60000);
    return x.toISOString().slice(0, 10);
  };
  const checkin = document.getElementById('hero-checkin');
  const checkout = document.getElementById('hero-checkout');
  if (checkin) {
    checkin.min = localDate(today);
    checkin.addEventListener('change', () => {
      const next = new Date(checkin.value + 'T00:00:00');
      next.setDate(next.getDate() + 1);
      if (checkout) { checkout.min = localDate(next); if (checkout.value && checkout.value <= checkin.value) checkout.value = ''; }
    });
  }
  const detailIn = document.getElementById('checkin');
  const detailOut = document.getElementById('checkout');
  if (detailIn && detailOut) detailIn.addEventListener('change', () => {
    const next = new Date(detailIn.value + 'T00:00:00');
    next.setDate(next.getDate() + 1);
    detailOut.min = localDate(next);
    if (detailOut.value && detailOut.value <= detailIn.value) detailOut.value = '';
  });
});
