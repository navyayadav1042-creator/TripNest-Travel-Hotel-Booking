<?php
require_once "../config/db.php";
if (session_status() === PHP_SESSION_NONE) session_start();
if (($_SESSION['role'] ?? '') !== 'admin') { http_response_code(403); exit("Admin access only. Sign in with an admin account."); }
$users=(int)$pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
$hotels=(int)$pdo->query("SELECT COUNT(*) FROM hotels")->fetchColumn();
$bookings=(int)$pdo->query("SELECT COUNT(*) FROM bookings")->fetchColumn();
$revenue=(float)$pdo->query("SELECT COALESCE(SUM(total_amount),0) FROM bookings WHERE status='confirmed'")->fetchColumn();
$pageTitle="Admin dashboard | TripNest"; require "../includes/header.php";
?>
<section class="section"><span class="eyebrow">TRIPNEST CONTROL CENTRE</span><h1>Admin dashboard</h1><p>Overview of your travel booking database.</p>
<div class="stats-grid"><div class="stat-card"><span>Registered users</span><strong><?= $users ?></strong></div><div class="stat-card"><span>Hotels</span><strong><?= $hotels ?></strong></div><div class="stat-card"><span>Bookings</span><strong><?= $bookings ?></strong></div><div class="stat-card"><span>Confirmed booking value</span><strong>₹<?= number_format($revenue) ?></strong></div></div>
<div class="admin-panel"><h2>Recent bookings</h2><?php $recent=$pdo->query("SELECT b.booking_id,b.check_in,b.check_out,b.total_amount,b.status,u.name,h.hotel_name FROM bookings b JOIN users u ON u.user_id=b.user_id JOIN rooms r ON r.room_id=b.room_id JOIN hotels h ON h.hotel_id=r.hotel_id ORDER BY b.booked_at DESC LIMIT 10")->fetchAll(); ?>
<div class="table-wrap"><table><thead><tr><th>ID</th><th>Guest</th><th>Hotel</th><th>Dates</th><th>Amount</th><th>Status</th></tr></thead><tbody><?php foreach($recent as $r): ?><tr><td>#<?= $r['booking_id'] ?></td><td><?= htmlspecialchars($r['name']) ?></td><td><?= htmlspecialchars($r['hotel_name']) ?></td><td><?= htmlspecialchars($r['check_in']) ?> – <?= htmlspecialchars($r['check_out']) ?></td><td>₹<?= number_format((float)$r['total_amount']) ?></td><td><?= htmlspecialchars($r['status']) ?></td></tr><?php endforeach; ?></tbody></table></div></div></section>
<?php require "../includes/footer.php"; ?>
